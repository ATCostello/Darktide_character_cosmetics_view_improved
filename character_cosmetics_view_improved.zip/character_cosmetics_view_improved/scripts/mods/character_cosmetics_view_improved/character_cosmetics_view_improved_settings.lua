local mod = get_mod("character_cosmetics_view_improved")

return settings("character_cosmetics_view_improved_settings")