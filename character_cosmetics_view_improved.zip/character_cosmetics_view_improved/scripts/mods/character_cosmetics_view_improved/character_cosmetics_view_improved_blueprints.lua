local mod = get_mod("character_cosmetics_view_improved")
local Settings = mod:io_dofile("character_cosmetics_view_improved/scripts/mods/character_cosmetics_view_improved/character_cosmetics_view_improved_settings")

local blueprints = {

}

return blueprints